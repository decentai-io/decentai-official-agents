"""The attempts themselves: a connection opened and closed, and what
became of it.

    through the proxy   in the sandbox a program's one way out is a
                        proxy at 127.0.0.1:3128, named in HTTPS_PROXY,
                        which carries each connection to the runtime's
                        way out; it knows the program by where the
                        connection arrived. It is asked for a tunnel to
                        the host, and its answer is the outcome: it
                        opens what the agent declared and refuses the
                        rest, saying why.
    past the proxy      a connection made straight to an address, and a
                        name looked up: what a program could always do
                        before anything held it.

Four outcomes, and they are different things:

    reached       the connection was opened
    refused       the platform stopped it, and ``reason`` is its own
    unreachable   it was allowed, and the host did not answer
    not_tried     this agent would not try it
"""

from __future__ import annotations

import ipaddress
import json
import os
import re
import socket
from typing import Optional, Tuple
from urllib.parse import urlsplit

#: The sandbox's way out, where there is one.
PROXY_VARIABLE = "HTTPS_PROXY"
#: The web agents' escape for tests, honoured here as they honour it:
#: this machine's own addresses may be tried.
LOOPBACK_VARIABLE = "DECENTAI_WEB_ALLOW_LOOPBACK"
#: For this agent's own tests, which have no internet to try: the port
#: a named host is tried on, what stands for the address and the
#: name tried past the proxy, and where a name is found when nothing
#: looks one up. JSON: {"port": 8443, "direct": "127.0.0.1:8443",
#: "name": "localhost", "resolve": {"example.com": "127.0.0.1"}}.
TEST_VARIABLE = "DECENTAI_AGENT_CONNECTION_CHECK_TEST"

HOST_RE = re.compile(
    r"^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)*$")

REACHED, REFUSED, UNREACHABLE, NOT_TRIED = (
    "reached", "refused", "unreachable", "not_tried")


class NotAnAddress(ValueError):
    """What the person named is not a host this agent can try."""


class Outcome:
    def __init__(self, outcome: str, reason: str = ""):
        self.outcome = outcome
        self.reason = reason


class Attempts:
    SECONDS = 10

    def __init__(self):
        self.proxy = urlsplit(os.environ.get(PROXY_VARIABLE) or "")
        try:
            self.test = json.loads(os.environ.get(TEST_VARIABLE) or "{}")
        except ValueError:
            self.test = {}

    # ------------------------------------------------------------------
    # What is tried
    # ------------------------------------------------------------------

    @property
    def through_the_proxy(self) -> bool:
        """Whether this program was pointed at a way out."""
        return bool(self.proxy.hostname and self.proxy.port)

    @property
    def port(self) -> int:
        """The port a named host is tried on: where a service answers."""
        return int(self.test.get("port") or 443)

    @property
    def direct(self) -> Tuple[str, int]:
        """An address on the internet, written as one: no name has to
        be looked up to try it."""
        host, _, port = str(self.test.get("direct") or "1.1.1.1:443").rpartition(":")
        return host, int(port)

    @property
    def name(self) -> str:
        return str(self.test.get("name") or "example.com")

    @staticmethod
    def where(address: str) -> Tuple[str, Optional[int]]:
        """(host, port) of what a person typed: a name, a name and a
        port, or a whole address. The port is None where none was
        said."""
        address = str(address or "").strip()
        if not address:
            raise NotAnAddress("No address was given.")
        scheme = ""
        if "://" in address:
            scheme = address.split("://", 1)[0].lower()
            if scheme not in ("http", "https"):
                raise NotAnAddress(
                    f"{scheme}:// is not tried; name a host, or an http or https address.")
        try:
            parts = urlsplit(address if scheme else "//" + address)
            host, port = (parts.hostname or "").lower().rstrip("."), parts.port
        except ValueError:
            raise NotAnAddress(f"'{address}' is not an address this agent can read.")
        if parts.username or parts.password:
            raise NotAnAddress("An address with a name and a password in it is not tried.")
        if not host or not (HOST_RE.match(host) or Attempts.is_address(host)):
            raise NotAnAddress(f"'{address}' names no host.")
        if port is None and scheme == "http":
            port = 80
        return host, port

    @staticmethod
    def is_address(host: str) -> bool:
        try:
            ipaddress.ip_address(host.strip("[]"))
            return True
        except ValueError:
            return False

    # ------------------------------------------------------------------
    # Trying
    # ------------------------------------------------------------------

    def reach(self, host: str, port: int) -> Outcome:
        """The host, the way this agent is given to reach anything:
        through the platform's proxy where there is one."""
        if self.through_the_proxy:
            return self.by_the_proxy(host, port)
        return self.unheld(host, port)

    def by_the_proxy(self, host: str, port: int) -> Outcome:
        """Ask the way out for a tunnel. A refusal is answered at once,
        its reason in the platform's own words: the first line after the
        answer's head, else the answer's own first line. A host it
        opened and could not reach, it closes on without a word."""
        target = f"[{host}]:{port}" if ":" in host else f"{host}:{port}"
        try:
            with socket.create_connection(
                    (self.proxy.hostname, self.proxy.port), self.SECONDS) as link:
                link.settimeout(self.SECONDS * 3)
                link.sendall(f"CONNECT {target} HTTP/1.1\r\nHost: {target}\r\n\r\n".encode())
                answer = b""
                while len(answer) < 4096:
                    chunk = link.recv(4096)
                    if not chunk:
                        break
                    answer += chunk
                    head, ended, _ = answer.partition(b"\r\n\r\n")
                    if ended and re.match(rb"^HTTP/\d\.\d 200", head):
                        break
        except OSError as exc:
            return Outcome(UNREACHABLE, f"The way out did not answer: {self.short(exc)}")
        if not answer:
            return Outcome(UNREACHABLE, "The way out ended the connection without an "
                                        "answer: it could not be reached.")
        head, _, body = answer.partition(b"\r\n\r\n")
        found = re.match(r"^HTTP/\d\.\d (\d{3}) ?(.*)$",
                         head.split(b"\r\n", 1)[0].decode("latin-1", "replace"))
        if not found:
            return Outcome(UNREACHABLE, "The way out gave no answer that can be read.")
        status = int(found.group(1))
        said = next((line.strip() for line in body.decode("utf-8", "replace").splitlines()
                     if line.strip()), "") or found.group(2).strip()
        if status == 200:
            return Outcome(REACHED)
        if status in (502, 504):
            return Outcome(UNREACHABLE, said or "The host did not answer.")
        return Outcome(REFUSED, said or f"The way out answered {status}.")

    def unheld(self, host: str, port: int) -> Outcome:
        """No proxy: the connection is made straight from here, as any
        program would make it. An address inside the network is not
        tried: nothing here would have stopped it, and that is not a
        reason to knock on it."""
        known = (self.test.get("resolve") or {}).get(host)
        try:
            found = [(None, None, None, None, (known, port))] if known else (
                socket.getaddrinfo(host, port, type=socket.SOCK_STREAM))
        except OSError as exc:
            return Outcome(UNREACHABLE, f"{host} was not found: {self.short(exc)}")
        addresses = sorted({entry[4][0] for entry in found})
        inside = [a for a in addresses if not self.public(a)]
        if inside:
            return Outcome(
                NOT_TRIED,
                f"{host} is an address inside the network ({inside[0]}). Nothing "
                f"here would have refused it; this agent does not try one.")
        return self.straight(addresses[0], port)

    def straight(self, address: str, port: int) -> Outcome:
        """A connection to an address, asking nobody."""
        try:
            socket.create_connection((address, port), self.SECONDS).close()
        except OSError as exc:
            return Outcome(self.kind_of(exc), self.short(exc))
        return Outcome(REACHED)

    def looked_up(self, name: str) -> Outcome:
        """A name looked up from here. A program that is held cannot
        look one up: the way out does, for the hosts it opens.

        A lookup that fails is ``unreachable``, never ``refused``: no
        name service answered, and that is all it shows. The platform
        refusing it and this machine's own name service being down look
        the same from here, and ``refused`` means the platform stopped
        it, in its own words, which a failed lookup never carries."""
        try:
            socket.getaddrinfo(name, 443, type=socket.SOCK_STREAM)
        except OSError as exc:
            return Outcome(UNREACHABLE, f"No name could be looked up from here ({self.short(exc)}): no lookup "
                                        f"got out, though this does not show what stopped it.")
        return Outcome(REACHED)

    # ------------------------------------------------------------------
    def public(self, address: str) -> bool:
        found = ipaddress.ip_address(address)
        if found.is_loopback and os.environ.get(LOOPBACK_VARIABLE) == "1":
            return True
        return found.is_global

    @staticmethod
    def kind_of(exc: OSError) -> str:
        """Refused by what holds the program, or not answered by the
        host. A firewall that rejects says so at once: no route, not
        permitted, refused. A host that is only away says nothing until
        the time is up."""
        if isinstance(exc, (socket.timeout, TimeoutError)):
            return UNREACHABLE
        return REFUSED

    @staticmethod
    def short(exc: Exception) -> str:
        said = str(getattr(exc, "strerror", "") or exc).strip()
        return (said or type(exc).__name__)[:160]
