"""Recurring tasks: the rule is kept in code, never left to the model. A task that repeats daily, weekly or monthly
has a due date; completing it makes the next one, due one step after the previous due date (not after the day it
was done, so a late completion doesn't drift the schedule). A monthly task keeps the day of the month it started
on: due the 31st, it is next due the 30th in a month of 30 days and the 31st again after that."""

from __future__ import annotations

import calendar
from datetime import date, timedelta
from typing import Optional

RULES = ("daily", "weekly", "monthly")


def next_due(due: date, rule: str, day_of_month: Optional[int] = None) -> date:
    if rule == "daily":
        return due + timedelta(days=1)
    if rule == "weekly":
        return due + timedelta(days=7)
    if rule == "monthly":
        year, month = (due.year + 1, 1) if due.month == 12 else (due.year, due.month + 1)
        wanted = day_of_month or due.day
        return date(year, month, min(wanted, calendar.monthrange(year, month)[1]))
    raise ValueError(f"no rule '{rule}'")


def first_after(due: date, rule: str, day_of_month: Optional[int], after: date) -> date:
    """The next due date strictly after `after`, when completion came so late that several were missed: a missed
    occurrence is not made just to be overdue."""
    found = next_due(due, rule, day_of_month)
    while found <= after:
        found = next_due(found, rule, day_of_month)
    return found
